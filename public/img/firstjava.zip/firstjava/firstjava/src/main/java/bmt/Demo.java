package bmt;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Demo extends JFrame {

    private DefaultTableModel tableModel;
    private final List<FileData> fileDataList;

    Demo() {
        setSize(1000, 500);
        setTitle("Home Page");
        setLayout(null);
        setLocationRelativeTo(null);

        fileDataList = new ArrayList<>();

        JButton b1 = new JButton("ADD File");
        b1.setBounds(10, 10, 100, 30);
        add(b1);

        JButton b2 = new JButton("ADD Folder");
        b2.setBounds(10, 60, 100, 30);
        add(b2);

        JButton b3 = new JButton("Remove");
        b3.setBounds(10, 110, 100, 30);
        add(b3);

        String[] columns = {"S.No.", "Filename/Foldername", "Size", "Path"};
        tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(120, 10, 500, 200);
        add(scrollPane);

        JButton next = new JButton("Next");
        next.setBounds(380, 230, 100, 30);
        add(next);

        b1.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            
            // Set file filter to only allow CSV files
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files", "csv"));
            
            int option = fileChooser.showOpenDialog(Demo.this);
        
            if (option == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String filename = selectedFile.getName();
                long fileSize = selectedFile.length();
                String filePath = selectedFile.getAbsolutePath();
        
                int rowCount = tableModel.getRowCount() + 1;
                tableModel.addRow(new Object[]{rowCount, filename, formatFileSize(fileSize), filePath});
                fileDataList.add(new FileData(filename, formatFileSize(fileSize), filePath));
            }
        });
        

        b2.addActionListener(e -> {
            JFileChooser folderChooser = new JFileChooser();
            folderChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int option = folderChooser.showOpenDialog(Demo.this);

            if (option == JFileChooser.APPROVE_OPTION) {
                File selectedFolder = folderChooser.getSelectedFile();
                String folderName = selectedFolder.getName();
                long folderSize = calculateFolderSize(selectedFolder);
                String folderPath = selectedFolder.getAbsolutePath();

                int rowCount = tableModel.getRowCount() + 1;
                tableModel.addRow(new Object[]{rowCount, folderName, formatFileSize(folderSize), folderPath});
                fileDataList.add(new FileData(folderName, formatFileSize(folderSize), folderPath));
            }
        });

        b3.addActionListener(e -> {
            tableModel.setRowCount(0);
            fileDataList.clear();
        });

        next.addActionListener(e -> {
            new Demos(fileDataList);  // Pass fileDataList to Demos class
            dispose();  // Close Demo window
        });

        setVisible(true);
    }

    private long calculateFolderSize(File folder) {
        long totalSize = 0;
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    totalSize += file.length();
                } else if (file.isDirectory()) {
                    totalSize += calculateFolderSize(file);
                }
            }
        }
        return totalSize;
    }

    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return (size / 1024) + " KB";
        } else {
            return (size / (1024 * 1024)) + " MB";
        }
    }

    public static void main(String[] args) {
        new Demo();  // Launch Demo window
    }
}

class FileData {
    private final String name;
    private final String size;
    private final String path;

    public FileData(String name, String size, String path) {
        this.name = name;
        this.size = size;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public String getPath() {
        return path;
    }
}
