package bmt;

import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class Demos extends JFrame {

    private DefaultTableModel tableModel;

    public Demos(List<FileData> fileDataList) {
        setSize(1000, 500);
        setTitle("File List Viewer");
        setLayout(null);
        setLocationRelativeTo(null);

        // Create and set up the JTree (on the left side)
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Files");
        JTree tree = new JTree(root);
        JScrollPane treeScrollPane = new JScrollPane(tree);
        treeScrollPane.setBounds(10, 10, 400, 400); // Set the position and size of the JTree
        add(treeScrollPane);

        // Populate the JTree with file data
        for (FileData fileData : fileDataList) {
            File file = new File(fileData.getPath());
            if (file.isDirectory()) {
                DefaultMutableTreeNode folderNode = new DefaultMutableTreeNode(file.getAbsolutePath());
                root.add(folderNode);
                addFolderContentsToTree(file, folderNode);
            } else {
                root.add(new DefaultMutableTreeNode(file.getAbsolutePath()));
            }
        }

        DefaultTreeModel treeModel = new DefaultTreeModel(root);
        tree.setModel(treeModel);

        // Create the table columns
        String[] columns = {"S.No.", "Filename", "Size", "Path"};

        // Initialize the table model
        tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);

        // Add file data to the table
        for (int i = 0; i < fileDataList.size(); i++) {
            FileData fileData = fileDataList.get(i);
            tableModel.addRow(new Object[]{i + 1, fileData.getName(), fileData.getSize(), fileData.getPath()});
        }

        // Add table to JScrollPane (on the right side)
        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setBounds(420, 10, 500, 300); // Set the position and size of the JTable
        add(tableScrollPane);

        // Create "Clear List" button
        JButton clearList = new JButton("Clear List");
        clearList.setBounds(10, 420, 150, 30);
        add(clearList);

        // Create "Next" button
        JButton next = new JButton("Next");
        next.setBounds(420, 320, 150, 30);
        add(next);

        // Action for the "Clear List" button
        clearList.addActionListener(e -> tableModel.setRowCount(0)); // Clear all rows from the table

        // Action for the "Next" button
        next.addActionListener(e -> {
            int selectedRow = table.getSelectedRow(); // Get selected row from the JTable
            if (selectedRow != -1) {
                String selectedFilePath = (String) tableModel.getValueAt(selectedRow, 3); // Get the file path from the selected row
                new Demoss(selectedFilePath); // Pass the file path to Demoss class
                dispose(); // Close Demos window
            } else {
                JOptionPane.showMessageDialog(this, "Please select a file from the table.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        tree.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) { // Detect double-click
                    DefaultMutableTreeNode selectedNode =
                        (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
        
                    if (selectedNode == null) {
                        System.out.println("No node selected.");
                        return; // No node selected
                    }
        
                    // Get the full file path from the node's user object
                    String selectedPath = selectedNode.getUserObject().toString();
                    File selectedFile = new File(selectedPath);
        
                    if (selectedFile.isDirectory()) {
                        // Check if the directory contains CSV files
                        File[] files = selectedFile.listFiles((dir, name) -> name.toLowerCase().endsWith(".csv"));
                        if (files == null || files.length == 0) {
                            // Show error if no CSV files are found
                            JOptionPane.showMessageDialog(Demos.this,
                                "This folder does not contain any CSV files.",
                                "No CSV Files",
                                JOptionPane.ERROR_MESSAGE);
                        } else {
                            // Optionally, add folder's CSV contents to the table
                            for (File file : files) {
                                if (!isFileInTable(file.getAbsolutePath())) {
                                    tableModel.addRow(new Object[]{
                                        tableModel.getRowCount() + 1,   // S.No.
                                        file.getName(),                // Filename
                                        file.length(),                 // Size
                                        file.getAbsolutePath()         // Path
                                    });
                                }
                            }
                        }
                    } else if (selectedFile.isFile()) {
                        System.out.println("File detected: " + selectedFile.getName());
        
                        // Add file details to the table if not already present
                        if (!isFileInTable(selectedFile.getAbsolutePath())) {
                            tableModel.addRow(new Object[]{
                                tableModel.getRowCount() + 1,   // S.No.
                                selectedFile.getName(),         // Filename
                                selectedFile.length(),          // Size
                                selectedFile.getAbsolutePath()  // Path
                            });
                            System.out.println("File added to table.");
                        } else {
                            System.out.println("File already in table.");
                        }
                    } else {
                        System.out.println("Selected node is not a file or directory.");
                    }
                }
            }
        });
        

        setVisible(true);
    }

    

    /**
     * Adds folder contents to the tree. Returns true if the folder contains at least one CSV file.
     */
    private boolean addFolderContentsToTree(File folder, DefaultMutableTreeNode folderNode) {
        boolean containsCsv = false;
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    DefaultMutableTreeNode subFolderNode = new DefaultMutableTreeNode(file.getAbsolutePath());
                    folderNode.add(subFolderNode);
                    if (addFolderContentsToTree(file, subFolderNode)) {
                        containsCsv = true; // Propagate CSV existence from subfolders
                    }
                } else if (file.isFile() && file.getName().toLowerCase().endsWith(".csv")) {
                    folderNode.add(new DefaultMutableTreeNode(file.getAbsolutePath()));
                    containsCsv = true;
                }
            }
        }
        return containsCsv;
    }

    /**
     * Checks if a file is already in the table to prevent duplicates.
     */
    private boolean isFileInTable(String filePath) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 3).equals(filePath)) {
                return true; // File is already in the table
            }
        }
        return false;
    }
}
