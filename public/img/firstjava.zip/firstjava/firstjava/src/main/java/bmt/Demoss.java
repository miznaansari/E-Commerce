package bmt;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class Demoss extends JFrame {

    private Date selectedStartDate;
    private Date selectedEndDate;

    public Demoss(String filePath) {
        setSize(1000, 600);
        setTitle("File Conversion");
        setLayout(null);
        setLocationRelativeTo(null);

        // Add "PDF" option to file type dropdown
        String[] fileTypes = {"Select File Type", "Excel", "Text", "PDF"};
        JComboBox<String> fileTypeComboBox = new JComboBox<>(fileTypes);
        fileTypeComboBox.setBounds(20, 20, 150, 30);
        add(fileTypeComboBox);

        JLabel filePathLabel = new JLabel("File Path:");
        filePathLabel.setBounds(20, 60, 80, 30);
        add(filePathLabel);

        JTextField t1 = new JTextField(filePath);  // File path is pre-set from Demos.java
        t1.setBounds(20, 100, 300, 30);
        add(t1);

        // Date Range Radio Buttons
        JRadioButton last7DaysRadio = new JRadioButton("Last 7 days");
        last7DaysRadio.setBounds(20, 150, 150, 30);
        add(last7DaysRadio);

        JRadioButton last30DaysRadio = new JRadioButton("Last 30 days");
        last30DaysRadio.setBounds(20, 200, 150, 30);
        add(last30DaysRadio);

        JRadioButton customRangeRadio = new JRadioButton("Custom Range");
        customRangeRadio.setBounds(20, 250, 150, 30);
        add(customRangeRadio);

        ButtonGroup dateGroup = new ButtonGroup();
        dateGroup.add(last7DaysRadio);
        dateGroup.add(last30DaysRadio);
        dateGroup.add(customRangeRadio);
 
        // start date
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setBounds(400, 150, 80, 30);
        startDateLabel.setVisible(false);  // Initially hidden
        add(startDateLabel);

        JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
        startDateSpinner.setBounds(480, 150, 150, 30);
        startDateSpinner.setVisible(false);  // Initially hidden
        JSpinner.DateEditor startDateEditor = new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd");
        startDateSpinner.setEditor(startDateEditor);
        add(startDateSpinner);

        // end date
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setBounds(400, 200, 80, 30);
        endDateLabel.setVisible(false);  // Initially hidden
        add(endDateLabel);

        JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());
        endDateSpinner.setBounds(480, 200, 150, 30);
        endDateSpinner.setVisible(false);  // Initially hidden
        JSpinner.DateEditor endDateEditor = new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd");
        endDateSpinner.setEditor(endDateEditor);
        add(endDateSpinner);

        // Show/hide custom date pickers based on selection
        customRangeRadio.addActionListener(e -> {
            startDateLabel.setVisible(true);
            startDateSpinner.setVisible(true);
            endDateLabel.setVisible(true);
            endDateSpinner.setVisible(true);
        });

        last7DaysRadio.addActionListener(e -> {
            startDateLabel.setVisible(false);
            startDateSpinner.setVisible(false);
            endDateLabel.setVisible(false);
            endDateSpinner.setVisible(false);
        });

        last30DaysRadio.addActionListener(e -> {
            startDateLabel.setVisible(false);
            startDateSpinner.setVisible(false);
            endDateLabel.setVisible(false);
            endDateSpinner.setVisible(false);
        });

        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(20, 300, 150, 30);
        add(convertButton);

        JLabel statusLabel = new JLabel();
        statusLabel.setBounds(220, 250, 600, 30);
        add(statusLabel);

        convertButton.addActionListener(e -> {
            String selectedType = (String) fileTypeComboBox.getSelectedItem();

            // Determine the date range
            if (last7DaysRadio.isSelected()) {
                selectedEndDate = new Date();
                selectedStartDate = subtractDays(selectedEndDate, 7);
            } else if (last30DaysRadio.isSelected()) {
                selectedEndDate = new Date();
                selectedStartDate = subtractDays(selectedEndDate, 30);
            } else if (customRangeRadio.isSelected()) {
                selectedStartDate = (Date) startDateSpinner.getValue();
                selectedEndDate = (Date) endDateSpinner.getValue();
            }

            try {
                if (isFileWithinDateRange(filePath, selectedStartDate, selectedEndDate)) {
                    if ("Excel".equals(selectedType)) {
                        convertCsvToExcel(filePath);
                        statusLabel.setText("CSV converted to Excel successfully!");
                    } else if ("Text".equals(selectedType)) {
                        convertCsvToText(filePath);
                        statusLabel.setText("CSV converted to Text successfully!");
                    } else if ("PDF".equals(selectedType)) {
                        convertCsvToPdf(filePath);
                        statusLabel.setText("CSV converted to PDF successfully!");
                    } else {
                        statusLabel.setText("Please select a valid file type.");
                    }
                } else {
                    statusLabel.setText("File's last modified date is not within the selected range.");
                }
            } catch (Exception ex) {
                statusLabel.setText("Error: " + ex.getMessage());
            }
        });

        setVisible(true);
    }

    // Utility to subtract days from a date
    private Date subtractDays(Date date, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, -days);
        return calendar.getTime();
    }

    // Method to check if the file's last modified date is within the selected date range
    private boolean isFileWithinDateRange(String filePath, Date startDate, Date endDate) {
        try {
            Path path = Paths.get(filePath);
            long lastModifiedMillis = Files.getLastModifiedTime(path).toMillis();
            Date lastModifiedDate = new Date(lastModifiedMillis);

            return !lastModifiedDate.before(startDate) && !lastModifiedDate.after(endDate);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Methods for file conversion (CSV to Excel/Text/PDF) 
     private void convertCsvToExcel(String csvFilePath) throws IOException {
        if (!csvFilePath.endsWith(".csv")) {
            
            throw new IOException("The selected file is not a CSV file.");
        }

        String excelFilePath = csvFilePath.replace(".csv", ".xlsx");

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath));
             XSSFWorkbook workbook = new XSSFWorkbook()) {  // Using XSSFWorkbook which implements Workbook
            Sheet sheet = workbook.createSheet("Sheet1");
            String line;
            int rowNumber = 0;

            while ((line = br.readLine()) != null) {
                Row row = sheet.createRow(rowNumber++);
                String[] cells = line.split(",");

                for (int i = 0; i < cells.length; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(cells[i]);
                }
            }

            try (FileOutputStream fos = new FileOutputStream(excelFilePath)) {
                workbook.write(fos);
            }
        }
    }

    // Method to convert CSV to Text
    private void convertCsvToText(String csvFilePath) throws IOException {
        if (!csvFilePath.endsWith(".csv")) {
            throw new IOException("The selected file is not a CSV file.");
        }

        String textFilePath = csvFilePath.replace(".csv", ".txt");

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath));
             FileWriter writer = new FileWriter(textFilePath)) {
            String line;
            while ((line = br.readLine()) != null) {
                writer.write(line + System.lineSeparator());
            }
        }
    }

    // Method to convert CSV to PDF
    private void convertCsvToPdf(String csvFilePath) throws IOException {
        if (!csvFilePath.endsWith(".csv")) {
            throw new IOException("The selected file is not a CSV file.");
        }

        String pdfFilePath = csvFilePath.replace(".csv", ".pdf");

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            // Initialize PDF document and writer
            PdfDocument pdfDoc = new PdfDocument(new com.itextpdf.kernel.pdf.PdfWriter(pdfFilePath));
            Document document = new Document(pdfDoc);

            // Add a simple title
            document.add(new Paragraph("CSV Data").setFontSize(20));

            // Create a table with the number of columns in the CSV
            String line = br.readLine();
            if (line != null) {
                String[] headers = line.split(",");
                Table table = new Table(headers.length);

                // Add headers to the table
                for (String header : headers) {
                    table.addCell(header.trim()); // Added trim to remove extra spaces
                }

                // Add rows to the table
                while ((line = br.readLine()) != null) {
                    String[] cells = line.split(",");
                    for (String cell : cells) {
                        table.addCell(cell.trim()); // Added trim to remove extra spaces
                    }
                }

                document.add(table);
            } else {
                document.add(new Paragraph("CSV file is empty."));
            }

            // Close the document
            document.close();
        }
    }

    public static void main(String[] args) {
        new Demoss("sample.csv");
    }
}
